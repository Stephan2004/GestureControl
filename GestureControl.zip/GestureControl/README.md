# 👋 Gesture Control — App Android

Contrôlez votre écran Android avec des gestes de la main, sans le toucher.
Basé sur **MediaPipe Hand Landmarker** + **CameraX** + **AccessibilityService**.

---

## 🏗️ Structure du projet

```
GestureControl/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── assets/
│   │   └── hand_landmarker.task        ← À télécharger (voir étape 2)
│   ├── java/com/gesturecontrol/
│   │   ├── gestures/
│   │   │   ├── GestureType.kt          ← Enum de tous les gestes
│   │   │   ├── GestureClassifier.kt    ← Analyse des 21 landmarks
│   │   │   └── GestureActionDispatcher.kt ← Injection des touchers
│   │   ├── ml/
│   │   │   └── HandDetector.kt         ← Wrapper MediaPipe
│   │   ├── overlay/
│   │   │   ├── GestureOverlayService.kt   ← Service principal (caméra + overlay)
│   │   │   └── GestureAccessibilityService.kt ← Service accessibilité
│   │   └── ui/
│   │       └── MainActivity.kt         ← Interface principale
│   └── res/
│       ├── layout/
│       │   ├── activity_main.xml
│       │   └── overlay_gesture.xml     ← Indicateur flottant
│       ├── values/
│       │   ├── strings.xml
│       │   └── themes.xml
│       └── xml/
│           └── accessibility_service_config.xml
├── download_model.sh                   ← Script téléchargement modèle
└── README.md
```

---

## 🚀 Installation pas à pas

### Étape 1 — Prérequis
- **Android Studio** Hedgehog (2023.1) ou plus récent
- **JDK 17** (inclus avec Android Studio)
- Un téléphone Android **API 26+** (Android 8.0+)
- Le téléphone en **mode développeur** avec le débogage USB activé

### Étape 2 — Télécharger le modèle MediaPipe

Depuis le dossier `GestureControl/`, exécutez :

```bash
chmod +x download_model.sh
./download_model.sh
```

Ou téléchargez manuellement :
👉 https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

Placez le fichier dans :
```
app/src/main/assets/hand_landmarker.task
```

### Étape 3 — Ouvrir dans Android Studio

1. Ouvrez Android Studio
2. **File → Open** → sélectionnez le dossier `GestureControl`
3. Attendez que Gradle synchronise (peut prendre 2-3 minutes)
4. Connectez votre téléphone en USB
5. Cliquez sur **▶ Run** (Shift+F10)

### Étape 4 — Configurer l'app sur le téléphone

Une fois installée, l'app vous guidera pour activer 3 choses :

#### 4a. Permission Caméra
→ Accordez quand l'app la demande

#### 4b. Permission Overlay (Afficher par-dessus les apps)
→ Bouton **"Activer Overlay"** dans l'app
→ Paramètres → Applications → Gesture Control → Afficher par-dessus les autres apps ✓

#### 4c. Service d'Accessibilité (OBLIGATOIRE pour les clics réels)
→ Bouton **"Activer Accessibilité"** dans l'app
→ Paramètres → Accessibilité → Gesture Control → Activer ✓

> ⚠️ Sans le service d'accessibilité, les gestes sont détectés et affichés mais n'agissent pas sur l'écran.

---

## 🤟 Tableau des gestes

| Geste | Emoji | Action |
|-------|-------|--------|
| Poing fermé | ✊ | **Clic** à la position de la main |
| Main ouverte | ✋ | Pause |
| Index pointé + mouvement | 👆 | **Swipe** gauche/droite/haut/bas |
| Victory (2 doigts) | ✌️ | **Scroll** vers le haut |
| Pouce levé | 👍 | **Retour** (Back) |
| Shaka (pouce + auriculaire) | 🤙 | **Accueil** (Home) |
| Paume face caméra | 🖐️ | Stop |
| Pince (pouce + index) | 🤏 | **Zoom -** |
| Écart (pouce + index) | 🖖 | **Zoom +** |

---

## 🧠 Comment ça marche ?

```
Caméra frontale
     ↓
CameraX (ImageAnalysis)
     ↓
MediaPipe HandLandmarker
     ↓  21 points de la main (landmarks)
GestureClassifier
     ↓  analyse angles + positions + historique
GestureType (enum)
     ↓
GestureActionDispatcher
     ↓
AccessibilityService.dispatchGesture()
     ↓
Toucher réel injecté sur l'écran
```

### Les 21 landmarks de la main

```
          8   12  16  20
          |   |   |   |
          7   11  15  19
          |   |   |   |
      4   6   10  14  18
      |   |   |   |   |
      3   5   9   13  17
       \  |   |   |   |
        2 |   |   |   |
         \|___|___|___|
              0 (poignet)
```

---

## 🔧 Personnaliser les gestes

Pour ajouter un nouveau geste, modifiez `GestureClassifier.kt` :

```kotlin
// Exemple : détecter 3 doigts levés → screenshot
val threeFingers = indexUp && middleUp && ringUp && !pinkyUp && !thumbUp
if (threeFingers) return GestureType.SCREENSHOT  // ajoutez dans l'enum
```

Puis dans `GestureActionDispatcher.kt` :
```kotlin
GestureType.SCREENSHOT -> performScreenshot()
```

---

## ❓ Problèmes fréquents

| Problème | Solution |
|----------|----------|
| "hand_landmarker.task not found" | Exécutez `download_model.sh` |
| Gestes pas détectés | Éclairage suffisant, main visible entièrement |
| Clics ne fonctionnent pas | Activez le Service d'Accessibilité |
| Overlay ne s'affiche pas | Activez la permission Overlay |
| App plante au démarrage | Vérifiez que la permission Caméra est accordée |

---

## 📋 Permissions requises

| Permission | Raison |
|------------|--------|
| `CAMERA` | Capturer la vidéo de la main |
| `SYSTEM_ALERT_WINDOW` | Afficher l'indicateur de geste par-dessus |
| `FOREGROUND_SERVICE` | Rester actif en arrière-plan |
| `BIND_ACCESSIBILITY_SERVICE` | Injecter des touchers réels |
| `VIBRATE` | Retour haptique sur geste reconnu |

---

## 🛠️ Technologies utilisées

- **Kotlin** — langage principal
- **MediaPipe Tasks Vision** 0.10.8 — détection de la main
- **CameraX** 1.3.0 — accès caméra moderne
- **AccessibilityService** — injection de gestes système
- **WindowManager** — overlay flottant
- **LifecycleService** — service lifecycle-aware
