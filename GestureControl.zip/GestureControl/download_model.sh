#!/bin/bash
# ==================================================
#  download_model.sh
#  Télécharge le modèle MediaPipe Hand Landmarker
# ==================================================

ASSETS_DIR="app/src/main/assets"
MODEL_FILE="$ASSETS_DIR/hand_landmarker.task"
MODEL_URL="https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

mkdir -p "$ASSETS_DIR"

if [ -f "$MODEL_FILE" ]; then
  echo "✓ Modèle déjà présent : $MODEL_FILE"
  exit 0
fi

echo "⬇ Téléchargement du modèle MediaPipe Hand Landmarker..."
curl -L "$MODEL_URL" -o "$MODEL_FILE"

if [ $? -eq 0 ]; then
  echo "✓ Modèle téléchargé avec succès !"
  echo "  Taille : $(du -h $MODEL_FILE | cut -f1)"
else
  echo "✗ Échec du téléchargement."
  echo "  Téléchargez manuellement depuis :"
  echo "  $MODEL_URL"
  echo "  Et placez-le dans : $ASSETS_DIR/"
fi
