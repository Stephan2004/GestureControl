package com.gesturecontrol.gestures

/**
 * Tous les gestes reconnus par l'application
 */
enum class GestureType {
    // ✋ Main ouverte → pause / stop
    OPEN_HAND,

    // ✊ Poing fermé → clic
    FIST,

    // 👆 Index pointé → curseur / navigation
    POINTING,

    // ✌️ Victory / deux doigts → scroll haut
    VICTORY,

    // 👍 Pouce levé → action positive / retour
    THUMBS_UP,

    // 👎 Pouce baissé → action négative
    THUMBS_DOWN,

    // 🤙 Shaka (pouce + auriculaire) → capture écran
    SHAKA,

    // 🖐️ Paume vers caméra → stop / pause media
    STOP,

    // Geste directionnel (index qui pointe et bouge)
    SWIPE_LEFT,
    SWIPE_RIGHT,
    SWIPE_UP,
    SWIPE_DOWN,

    // Pince (pouce + index rapprochés) → zoom out
    PINCH,

    // Spread (pouce + index écartés) → zoom in
    SPREAD,

    // Aucun geste détecté
    NONE
}
