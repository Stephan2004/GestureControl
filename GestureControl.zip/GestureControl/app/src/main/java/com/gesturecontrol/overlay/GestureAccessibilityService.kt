package com.gesturecontrol.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Service d'accessibilité requis pour injecter des touchers réels.
 * L'utilisateur doit l'activer dans :
 *   Paramètres → Accessibilité → Gesture Control
 */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        var instance: GestureAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
        val info = AccessibilityServiceInfo().apply {
            flags = AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
        }
        serviceInfo = info

        // Transmettre l'instance au dispatcher dans l'overlay service
        updateDispatcher()
    }

    private fun updateDispatcher() {
        // Si le service overlay tourne, on lui injecte notre instance
        // Le dispatcher utilisera ce service pour les gestes réels
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
}
