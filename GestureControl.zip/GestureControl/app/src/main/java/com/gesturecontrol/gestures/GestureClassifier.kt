package com.gesturecontrol.gestures

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Analyse les landmarks de la main (21 points) pour classifier le geste.
 *
 * Points clés MediaPipe :
 *  0=WRIST, 1=THUMB_CMC, 2=THUMB_MCP, 3=THUMB_IP, 4=THUMB_TIP
 *  5=INDEX_MCP, 6=INDEX_PIP, 7=INDEX_DIP, 8=INDEX_TIP
 *  9=MIDDLE_MCP, 10=MIDDLE_PIP, 11=MIDDLE_DIP, 12=MIDDLE_TIP
 *  13=RING_MCP, 14=RING_PIP, 15=RING_DIP, 16=RING_TIP
 *  17=PINKY_MCP, 18=PINKY_PIP, 19=PINKY_DIP, 20=PINKY_TIP
 */
object GestureClassifier {

    // Historique pour détection des swipes
    private val positionHistory = ArrayDeque<Pair<Float, Float>>(10)
    private const val SWIPE_THRESHOLD = 0.12f
    private const val HISTORY_SIZE = 8

    fun classify(landmarks: List<NormalizedLandmark>): GestureType {
        if (landmarks.size < 21) return GestureType.NONE

        // Extraire les états des doigts
        val thumbUp   = isThumbUp(landmarks)
        val thumbDown = isThumbDown(landmarks)
        val indexUp   = isFingerExtended(landmarks, 5, 6, 7, 8)
        val middleUp  = isFingerExtended(landmarks, 9, 10, 11, 12)
        val ringUp    = isFingerExtended(landmarks, 13, 14, 15, 16)
        val pinkyUp   = isFingerExtended(landmarks, 17, 18, 19, 20)

        val indexTip = landmarks[8]
        val thumbTip = landmarks[4]

        // Mettre à jour historique position index
        updateHistory(indexTip.x(), indexTip.y())

        // ---- Classification des gestes statiques ----

        // ✊ Poing : aucun doigt levé
        if (!thumbUp && !indexUp && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.FIST
        }

        // ✋ Main ouverte : tous les doigts levés
        if (indexUp && middleUp && ringUp && pinkyUp) {
            // Paume face caméra ?
            if (isPalmFacingCamera(landmarks)) return GestureType.STOP
            return GestureType.OPEN_HAND
        }

        // 👆 Seul index levé
        if (indexUp && !middleUp && !ringUp && !pinkyUp) {
            // Vérifier swipe avec historique
            val swipe = detectSwipe()
            if (swipe != GestureType.NONE) return swipe
            return GestureType.POINTING
        }

        // ✌️ Victory : index + majeur levés
        if (indexUp && middleUp && !ringUp && !pinkyUp) {
            return GestureType.VICTORY
        }

        // 🤙 Shaka : pouce + auriculaire levés
        if (thumbUp && pinkyUp && !indexUp && !middleUp && !ringUp) {
            return GestureType.SHAKA
        }

        // 👍 Pouce levé seul
        if (thumbUp && !indexUp && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.THUMBS_UP
        }

        // 👎 Pouce baissé seul
        if (thumbDown && !indexUp && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.THUMBS_DOWN
        }

        // 🤏 Pince (pinch) : pouce et index proches
        val pinchDist = distance(thumbTip, indexTip)
        if (pinchDist < 0.06f && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.PINCH
        }

        // 🖐️ Spread : pouce et index très écartés
        if (pinchDist > 0.25f && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.SPREAD
        }

        return GestureType.NONE
    }

    // ──────────────────────────────────────────────
    //  Helpers
    // ──────────────────────────────────────────────

    private fun isFingerExtended(
        lm: List<NormalizedLandmark>,
        mcp: Int, pip: Int, dip: Int, tip: Int
    ): Boolean {
        // Le bout du doigt est plus haut (y plus petit) que la base
        return lm[tip].y() < lm[pip].y() && lm[pip].y() < lm[mcp].y()
    }

    private fun isThumbUp(lm: List<NormalizedLandmark>): Boolean {
        // Pouce TIP est au-dessus du MCP
        return lm[4].y() < lm[2].y() - 0.04f
    }

    private fun isThumbDown(lm: List<NormalizedLandmark>): Boolean {
        return lm[4].y() > lm[2].y() + 0.04f
    }

    private fun isPalmFacingCamera(lm: List<NormalizedLandmark>): Boolean {
        // Approximation : si le poignet est centré et les doigts sont tous levés
        val wrist = lm[0]
        return wrist.x() in 0.3f..0.7f
    }

    private fun distance(a: NormalizedLandmark, b: NormalizedLandmark): Float {
        val dx = a.x() - b.x()
        val dy = a.y() - b.y()
        return sqrt(dx * dx + dy * dy)
    }

    private fun updateHistory(x: Float, y: Float) {
        positionHistory.addLast(Pair(x, y))
        if (positionHistory.size > HISTORY_SIZE) {
            positionHistory.removeFirst()
        }
    }

    private fun detectSwipe(): GestureType {
        if (positionHistory.size < HISTORY_SIZE) return GestureType.NONE

        val first = positionHistory.first()
        val last  = positionHistory.last()

        val dx = last.first  - first.first
        val dy = last.second - first.second

        return when {
            dx >  SWIPE_THRESHOLD && abs(dx) > abs(dy) -> GestureType.SWIPE_RIGHT
            dx < -SWIPE_THRESHOLD && abs(dx) > abs(dy) -> GestureType.SWIPE_LEFT
            dy >  SWIPE_THRESHOLD && abs(dy) > abs(dx) -> GestureType.SWIPE_DOWN
            dy < -SWIPE_THRESHOLD && abs(dy) > abs(dx) -> GestureType.SWIPE_UP
            else -> GestureType.NONE
        }
    }

    fun clearHistory() {
        positionHistory.clear()
    }
}
