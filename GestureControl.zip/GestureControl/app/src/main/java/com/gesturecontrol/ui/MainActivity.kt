package com.gesturecontrol.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.gesturecontrol.databinding.ActivityMainBinding
import com.gesturecontrol.overlay.GestureOverlayService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Demande de permission caméra
    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) checkAndStart()
        else toast("Permission caméra requise !")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatus()
    }

    private fun setupUI() {
        // Bouton démarrer / arrêter
        binding.btnToggleService.setOnClickListener {
            if (GestureOverlayService.isRunning) stopService()
            else checkAndStart()
        }

        // Bouton permission overlay
        binding.btnOverlayPermission.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            }
        }

        // Bouton accessibilité
        binding.btnAccessibilitySettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun checkAndStart() {
        when {
            !hasCameraPermission() -> {
                cameraPermission.launch(Manifest.permission.CAMERA)
            }
            !hasOverlayPermission() -> {
                toast("Activez la permission 'Afficher par-dessus les apps'")
                binding.btnOverlayPermission.isEnabled = true
            }
            else -> startGestureService()
        }
    }

    private fun startGestureService() {
        val intent = Intent(this, GestureOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        updateServiceStatus()
    }

    private fun stopService() {
        stopService(Intent(this, GestureOverlayService::class.java))
        updateServiceStatus()
    }

    private fun updateServiceStatus() {
        val running = GestureOverlayService.isRunning
        binding.btnToggleService.text = if (running) "⏹ Arrêter le service" else "▶ Démarrer"
        binding.statusIndicator.text  = if (running) "● Actif" else "○ Inactif"
        binding.statusIndicator.setTextColor(
            if (running) getColor(android.R.color.holo_green_dark)
            else getColor(android.R.color.holo_red_light)
        )

        // Permissions
        binding.btnOverlayPermission.text =
            if (hasOverlayPermission()) "✓ Overlay OK" else "⚠ Activer Overlay"

        binding.btnAccessibilitySettings.text =
            if (isAccessibilityEnabled()) "✓ Accessibilité OK"
            else "⚠ Activer Accessibilité (pour clic réel)"
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED

    private fun hasOverlayPermission() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(this)
        else true

    private fun isAccessibilityEnabled(): Boolean {
        val prefString = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return prefString.contains(packageName, ignoreCase = true)
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
