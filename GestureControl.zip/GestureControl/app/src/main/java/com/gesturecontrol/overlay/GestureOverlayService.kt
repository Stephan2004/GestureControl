package com.gesturecontrol.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.gesturecontrol.R
import com.gesturecontrol.gestures.GestureActionDispatcher
import com.gesturecontrol.gestures.GestureType
import com.gesturecontrol.ml.HandDetector
import com.gesturecontrol.ui.MainActivity
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class GestureOverlayService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private var overlayView: android.view.View? = null
    private lateinit var handDetector: HandDetector
    private lateinit var cameraExecutor: ExecutorService
    private var dispatcher: GestureActionDispatcher? = null

    companion object {
        const val CHANNEL_ID = "GestureControlChannel"
        const val NOTIF_ID = 1
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        cameraExecutor = Executors.newSingleThreadExecutor()

        setupOverlay()
        setupCamera()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    // ──────────────────────────────────────────────
    //  Overlay flottant (indicateur de geste)
    // ──────────────────────────────────────────────

    private fun setupOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // Obtenir dimensions écran
        val metrics = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val display = getSystemService(DisplayManager::class.java).displays[0]
            display.getRealMetrics(metrics)
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
        }

        val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
        dispatcher = GestureActionDispatcher(
            screenWidth  = metrics.widthPixels,
            screenHeight = metrics.heightPixels,
            vibrator     = vibrator
            // accessibilityService sera null si pas activé
            // L'utilisateur doit activer le service d'accessibilité
        )

        // Vue overlay minimaliste
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_gesture, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 100
        }

        windowManager.addView(overlayView, params)
    }

    // ──────────────────────────────────────────────
    //  Caméra
    // ──────────────────────────────────────────────

    private fun setupCamera() {
        handDetector = HandDetector(this) { gesture, handX, handY ->
            // Dispatcher actions (si AccessibilityService disponible)
            dispatcher?.dispatch(gesture, handX, handY)

            // Mettre à jour l'overlay sur le thread UI
            runOnMainThread { updateOverlay(gesture) }
        }
        handDetector.initialize()

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val imageAnalysis = ImageAnalysis.Builder()
                .setTargetResolution(android.util.Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val bitmap = imageProxy.toBitmap()
                handDetector.processFrame(bitmap)
                imageProxy.close()
            }

            val cameraSelector = CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                .build()

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, imageAnalysis)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, mainExecutor)
    }

    // ──────────────────────────────────────────────
    //  UI Overlay
    // ──────────────────────────────────────────────

    private fun updateOverlay(gesture: GestureType) {
        val emojiView = overlayView?.findViewById<android.widget.TextView>(R.id.tvGestureEmoji)
        val nameView  = overlayView?.findViewById<android.widget.TextView>(R.id.tvGestureName)

        val (emoji, label) = when (gesture) {
            GestureType.OPEN_HAND   -> "✋" to "Main ouverte"
            GestureType.FIST        -> "✊" to "Clic"
            GestureType.POINTING    -> "👆" to "Curseur"
            GestureType.VICTORY     -> "✌️" to "Scroll haut"
            GestureType.THUMBS_UP   -> "👍" to "Retour"
            GestureType.THUMBS_DOWN -> "👎" to "Négatif"
            GestureType.SHAKA       -> "🤙" to "Accueil"
            GestureType.STOP        -> "🖐️" to "Stop"
            GestureType.SWIPE_LEFT  -> "👈" to "Gauche"
            GestureType.SWIPE_RIGHT -> "👉" to "Droite"
            GestureType.SWIPE_UP    -> "👆" to "Haut"
            GestureType.SWIPE_DOWN  -> "👇" to "Bas"
            GestureType.PINCH       -> "🤏" to "Zoom -"
            GestureType.SPREAD      -> "🖖" to "Zoom +"
            GestureType.NONE        -> "·" to ""
        }

        emojiView?.text = emoji
        nameView?.text  = label
    }

    // ──────────────────────────────────────────────
    //  Notification
    // ──────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Gesture Control",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Service de reconnaissance gestuelle actif" }

            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, GestureOverlayService::class.java).apply {
            action = "STOP"
        }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gesture Control actif")
            .setContentText("Bougez la main devant la caméra")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_delete, "Arrêter", stopPending)
            .setOngoing(true)
            .build()
    }

    // ──────────────────────────────────────────────
    //  Lifecycle
    // ──────────────────────────────────────────────

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == "STOP") stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handDetector.stop()
        cameraExecutor.shutdown()
        overlayView?.let { windowManager.removeView(it) }
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    private fun runOnMainThread(block: () -> Unit) {
        android.os.Handler(mainLooper).post(block)
    }
}
