package com.gesturecontrol.gestures

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Display
import androidx.annotation.RequiresApi

/**
 * Convertit un GestureType en action système réelle via AccessibilityService ou injection d'événement.
 * Utilisé par le GestureOverlayService.
 */
class GestureActionDispatcher(
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val vibrator: Vibrator?,
    private val accessibilityService: AccessibilityService? = null
) {
    // Curseur virtuel (pour le geste POINTING)
    var cursorX = screenWidth / 2f
    var cursorY = screenHeight / 2f

    // Cooldown pour éviter les répétitions rapides
    private var lastActionTime = 0L
    private val COOLDOWN_MS = 600L

    fun dispatch(gesture: GestureType, handX: Float, handY: Float) {
        val now = System.currentTimeMillis()

        // Mettre à jour position curseur depuis la main (normalisé 0..1 → pixels)
        // Note: caméra frontale = miroir, donc on inverse X
        cursorX = (1f - handX) * screenWidth
        cursorY = handY * screenHeight

        // Cooldown pour gestes discrets (pas pour mouvements continus)
        val isMovement = gesture in listOf(
            GestureType.POINTING, GestureType.NONE
        )

        if (!isMovement && now - lastActionTime < COOLDOWN_MS) return

        when (gesture) {
            GestureType.FIST       -> performClick(cursorX, cursorY)
            GestureType.SWIPE_LEFT -> performSwipe(SwipeDir.LEFT)
            GestureType.SWIPE_RIGHT-> performSwipe(SwipeDir.RIGHT)
            GestureType.SWIPE_UP   -> performSwipe(SwipeDir.UP)
            GestureType.SWIPE_DOWN -> performSwipe(SwipeDir.DOWN)
            GestureType.VICTORY    -> performScroll(up = true)
            GestureType.THUMBS_UP  -> performBack()
            GestureType.SHAKA      -> performHome()
            GestureType.OPEN_HAND  -> { /* pause - rien */ }
            GestureType.PINCH      -> performPinch(expand = false)
            GestureType.SPREAD     -> performPinch(expand = true)
            else -> return
        }

        if (!isMovement) {
            lastActionTime = now
            vibrate()
        }
    }

    // ──────────────────────────────────────────────
    //  Actions système via AccessibilityService
    // ──────────────────────────────────────────────

    private fun performClick(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 100)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            accessibilityService?.dispatchGesture(gesture, null, null)
        }
    }

    private fun performSwipe(dir: SwipeDir) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val cx = screenWidth / 2f
            val cy = screenHeight / 2f
            val dist = screenWidth * 0.3f

            val (startX, startY, endX, endY) = when (dir) {
                SwipeDir.LEFT  -> arrayOf(cx + dist, cy, cx - dist, cy)
                SwipeDir.RIGHT -> arrayOf(cx - dist, cy, cx + dist, cy)
                SwipeDir.UP    -> arrayOf(cx, cy + dist, cx, cy - dist)
                SwipeDir.DOWN  -> arrayOf(cx, cy - dist, cx, cy + dist)
            }

            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, 300)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            accessibilityService?.dispatchGesture(gesture, null, null)
        }
    }

    private fun performScroll(up: Boolean) {
        performSwipe(if (up) SwipeDir.UP else SwipeDir.DOWN)
    }

    private fun performBack() {
        accessibilityService?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    private fun performHome() {
        accessibilityService?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
    }

    private fun performPinch(expand: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val cx = screenWidth / 2f
            val cy = screenHeight / 2f
            val dist = if (expand) 50f else 200f
            val target = if (expand) 200f else 50f

            val path1 = Path().apply {
                moveTo(cx - dist, cy)
                lineTo(cx - target, cy)
            }
            val path2 = Path().apply {
                moveTo(cx + dist, cy)
                lineTo(cx + target, cy)
            }

            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path1, 0, 400))
                .addStroke(GestureDescription.StrokeDescription(path2, 0, 400))
                .build()
            accessibilityService?.dispatchGesture(gesture, null, null)
        }
    }

    private fun vibrate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(50)
        }
    }

    enum class SwipeDir { LEFT, RIGHT, UP, DOWN }
}
