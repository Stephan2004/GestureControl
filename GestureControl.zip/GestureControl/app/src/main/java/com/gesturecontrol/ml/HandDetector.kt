package com.gesturecontrol.ml

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.gesturecontrol.gestures.GestureClassifier
import com.gesturecontrol.gestures.GestureType

/**
 * Wrapper autour de MediaPipe HandLandmarker.
 * Détecte la main en temps réel et retourne le GestureType + position.
 */
class HandDetector(
    private val context: Context,
    private val onResult: (gesture: GestureType, handX: Float, handY: Float) -> Unit
) {
    private var handLandmarker: HandLandmarker? = null
    private var isRunning = false

    fun initialize() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.6f)
                .setMinHandPresenceConfidence(0.6f)
                .setMinTrackingConfidence(0.6f)
                .setResultListener { result, _ -> processResult(result) }
                .setErrorListener { error -> error.printStackTrace() }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(context, options)
            isRunning = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun processFrame(bitmap: Bitmap) {
        if (!isRunning || handLandmarker == null) return

        try {
            val mpImage = BitmapImageBuilder(bitmap).build()
            val timestamp = SystemClock.uptimeMillis()
            handLandmarker?.detectAsync(mpImage, timestamp)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun processResult(result: HandLandmarkerResult) {
        if (result.landmarks().isEmpty()) {
            onResult(GestureType.NONE, 0.5f, 0.5f)
            GestureClassifier.clearHistory()
            return
        }

        val landmarks = result.landmarks()[0]
        val gesture = GestureClassifier.classify(landmarks)

        // Position de référence = poignet (landmark 0)
        val wrist = landmarks[0]
        onResult(gesture, wrist.x(), wrist.y())
    }

    fun stop() {
        isRunning = false
        handLandmarker?.close()
        handLandmarker = null
    }
}
